<?php require_once("includes/db.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/sessions.php"); ?>

<?php require_once("includes/header.php"); ?>
<?php require_once("includes/nav.php"); ?>

 <div class="container">
     <div class="row mt-4">
       <div class="col-sm-8">
         <h1>Proto</h1>
         <h1 class="lead">Proto Custom Blog with Comment and Pagination System</h1>
			<?php 
				global $connectingDB;
				if(isset($_GET["SearchButton"])){
					$search = $_GET["Search"];
					$sql = "SELECT * FROM posts
					WHERE datetime LIKE :search
					OR title LIKE :search
					OR category LIKE :search
					OR post LIKE :search";
					$stmt = $connectingDB->prepare($sql);
					$stmt->bindValue(':search','%'.$search.'%');
					$stmt->execute();
				} else {
					$postIdFromURL = $_GET["id"];
					$sql = "SELECT * FROM posts WHERE id='$postIdFromURL'";
					$stmt = $connectingDB->query($sql);
					
				}
				while ($dataRows = $stmt->fetch()) {
					  $postId	        = $dataRows["id"];
					  $dateTime  		= $dataRows["datetime"];
                      $postTitle 		= $dataRows["title"];
                      $category  		= $dataRows["category"];
                      $admin     		= $dataRows["author"];
                      $image     		= $dataRows["image"];
                      $postDescription  = $dataRows["post"];
				
			 ?>

			 <div class="card">
			 	<img src="uploads/<?php echo htmlentities($image) ?>" style="max-height: 450px;" class="img-fluid card-img-top">
			 	<div class="card-body">
			 		<h4 class="card-title"><?php echo htmlentities($postTitle); ?></h4>
			 		 <small class="text-muted">Category: <span class="text-dark"> <a href="Blog.php?category=<?php echo htmlentities($category); ?>"> <?php echo htmlentities($category); ?> </a></span> & Written by <span class="text-dark"> <a href="#"> <?php echo htmlentities($admin); ?></a></span> On <span class="text-dark"><?php echo htmlentities($dateTime); ?></span></small>
                          <span style="float:right;" class="badge badge-dark text-light">Comments:20
			 </span>
                          <hr>
                          <p class="card-text">
                            <?php echo htmlentities($postDescription); ?></p>
                          <a href="blog.php" style="float:right;">
                            <span class="btn btn-info">Back to Blog &rang;&rang; </span>
                          </a>
                        </div>
                    </div>
                    <br>
			 <?php } ?>

       </div>
       <div class="col-sm-4 my-4" style="min-height: 50px; background: green; "></div>
     </div>
 </div>
<!-- HEADER END -->


<?php require_once("includes/footer.php"); ?>