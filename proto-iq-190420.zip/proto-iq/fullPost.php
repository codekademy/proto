<?php require_once("includes/db.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/sessions.php"); ?>

<?php 
	$searchQueryParameter = $_GET['id'];
	if(isset($_POST["Submit"])){
		$name = $_POST["CommenterName"];
		$email   = $_POST["CommenterEmail"];
	    $comment = $_POST["CommenterThoughts"];
	    date_default_timezone_set("Asia/Karachi");
	    $currentTime=time();
	    $dateTime=strftime("%B-%d-%Y %H:%M:%S",$currentTime); 

	     if(empty($name)||empty($email)||empty($comment)){
		    $_SESSION["ErrorMessage"]= "All fields must be filled out";
		    redirect_to("fullPost.php?id={$searchQueryParameter}");
		  }elseif (strlen($comment)>500) {
		    $_SESSION["ErrorMessage"]= "Comment length should be less than 500 characters";
		    redirect_to("fullPost.php?id={$searchQueryParameter}");
		  }else{
		  	// Query to insert comment in DB
   			global $connectingDB;
		    $sql  = "INSERT INTO comments(datetime,name,email,comment,approvedby,status,post_id)";
		    $sql .= "VALUES(:dateTime,:name,:email,:comment,'Pending','OFF',:postIdFromURL)";
		    $stmt = $connectingDB->prepare($sql);
		    $stmt -> bindValue(':dateTime',$dateTime);
		    $stmt -> bindValue(':name',$name);
		    $stmt -> bindValue(':email',$email);
		    $stmt -> bindValue(':comment',$comment);
		    $stmt -> bindValue(':postIdFromURL',$searchQueryParameter);
		    $execute = $stmt->execute();
		  	if($execute){
		  		$_SESSION['SuccessMessage']="Comment Submitted Successfully!";
		  		redirect_to("fullPost.php?id={$searchQueryParameter}");
		  	}else{
		  		$_SESSION['ErrorMessage']="Someting went wrong, Try Again!";
		  		redirect_to("fullPost.php?id={$searchQueryParameter}");
		  	}

		  }


	}

 ?>

<?php require_once("includes/header.php"); ?>
<?php require_once("includes/nav.php"); ?>

 <div class="container">
     <div class="row mt-4">
       <div class="col-sm-8">
         <h1>Proto</h1>
         <h1 class="lead">Proto Custom Blog with Comment and Pagination System</h1>
         <?php
           echo ErrorMessage();
           echo SuccessMessage();
           ?>
			<?php 
				global $connectingDB;
				if(isset($_GET["SearchButton"])){
					$search = $_GET["Search"];
					$sql = "SELECT * FROM posts
					WHERE datetime LIKE :search
					OR title LIKE :search
					OR category LIKE :search
					OR post LIKE :search";
					$stmt = $connectingDB->prepare($sql);
					$stmt->bindValue(':search','%'.$search.'%');
					$stmt->execute();
				} else {
					$postIdFromURL = $_GET["id"];
					$sql = "SELECT * FROM posts WHERE id='$postIdFromURL'";
					$stmt = $connectingDB->query($sql);
					
				}
				while ($dataRows = $stmt->fetch()) {
					  $postId	        = $dataRows["id"];
					  $dateTime  		= $dataRows["datetime"];
                      $postTitle 		= $dataRows["title"];
                      $category  		= $dataRows["category"];
                      $admin     		= $dataRows["author"];
                      $image     		= $dataRows["image"];
                      $postDescription  = $dataRows["post"];
				
			 ?>

			 <div class="card">
			 	<img src="uploads/<?php echo htmlentities($image) ?>" style="max-height: 450px;" class="img-fluid card-img-top">
			 	<div class="card-body">
			 		<h4 class="card-title"><?php echo htmlentities($postTitle); ?></h4>
			 		 <small class="text-muted">Category: <span class="text-dark"> <a href="Blog.php?category=<?php echo htmlentities($category); ?>"> <?php echo htmlentities($category); ?> </a></span> & Written by <span class="text-dark"> <a href="#"> <?php echo htmlentities($admin); ?></a></span> On <span class="text-dark"><?php echo htmlentities($dateTime); ?></span></small>
                          <span style="float:right;" class="badge badge-dark text-light">Comments:20
			 </span>
                          <hr>
                          <p class="card-text">
                            <?php echo htmlentities($postDescription); ?></p>
                          <a href="blog.php" style="float:right;">
                            <span class="btn btn-info">Back to Blog &rang;&rang; </span>
                          </a>
                        </div>
                    </div>
                    <br>
			 <?php } ?>
			<!-- Comments Form Start -->

			<span class="field-info text-primary d-inline-block mb-3">Comments</span>
			<?php 
				global $connectingDB;
				$sql = "SELECT * FROM comments
				WHERE post_id='$searchQueryParameter' AND status='ON'"; 
				$stmt = $connectingDB->query($sql);
				while ($dataRows = $stmt->fetch()) {
					$commentDate = $dataRows['datetime'];
					$commentName = $dataRows['name'];
					$commentContent = $dataRows['comment'];
				?>
			<div class="media CommentBlock">
				<img src="includes/images/user-1.jpg" class="d-block img-fluid align-self-start">
				<div class="media-body ml-2">
					<h6 class="lead"><?php echo $commentName; ?></h6>
					<p><?php echo $commentContent; ?></p>
				</div>
			</div>
			<?php } ?>		
          <div>
            <form class="" action="fullPost.php?id=<?php echo $searchQueryParameter ?>" method="post">
              <div class="card mb-3">
                <div class="card-header">
                  <h5 class="fieldInfo">Share your thoughts about this post</h5>
                </div>
                <div class="card-body">
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                      </div>
                    <input class="form-control" type="text" name="CommenterName" placeholder="Name" value="">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                      </div>
                    <input class="form-control" type="text" name="CommenterEmail" placeholder="Email" value="">
                    </div>
                  </div>
                  <div class="form-group">
                    <textarea name="CommenterThoughts" class="form-control" rows="6" cols="80"></textarea>
                  </div>
                  <div class="">
                    <button type="submit" name="Submit" class="btn btn-primary">Submit</button>
                  </div>
                </div>
              </div>
            </form>
          </div>
            <!-- Comment Part End -->	
       </div>
       <div class="col-sm-4 my-4" style="min-height: 50px; background: gold; "></div>
     </div>
 </div>
<!-- HEADER END -->


<?php require_once("includes/footer.php"); ?>