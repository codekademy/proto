<?php require_once("includes/db.php"); ?>	
<?php require_once("includes/functions.php"); ?>	
<?php require_once("includes/sessions.php"); ?>	
<?php 
	$serarchQueryPrameter = $_GET['id'];
	if(isset($_POST['Submit'])){
		$postTitle = $_POST["PostTitle"];
		$category  = $_POST["Category"];
		$image     = $_FILES["Image"]["name"]; 
		$target    = "uploads/".basename($_FILES["Image"]["name"]);
		$postDescription = $_POST["PostDescription"];
		$admin = "Tahir";
		date_default_timezone_set("Asia/Karachi");
		$currentTime = time();
		$datetime = strftime("%Y-%m-%d %H:%M:%S", $currentTime);

		if(empty($postTitle)){
		$_SESSION["ErrorMessage"] = "Title cant be empty";
		redirect_to("posts.php");
		} elseif(strlen($postTitle) < 3) {
				$_SESSION["ErrorMessage"] = "Post Title should be greater than 5 characters.";
				redirect_to("posts.php");
		} elseif(strlen($postTitle) > 49) {
					$_SESSION["ErrorMessage"] = "Post Title should be less than than 50 characters.";
					redirect_to("posts.php");
		}  else {
		 // Query to Update Post in DB When everything is fine
	    global $ConnectingDB;
	    if (!empty($_FILES["Image"]["name"])) {
	      $sql = "UPDATE posts
	              SET title='$postTitle', category='$category', image='$image', post='$postDescription'
	              WHERE id='$serarchQueryPrameter'";
	    }else {
	      $sql = "UPDATE posts
	              SET title='$postTitle', category='$category', post='$postDescription'
	              WHERE id='$serarchQueryPrameter'";
	    }
	    $execute= $connectingDB->query($sql);
	    move_uploaded_file($_FILES["Image"]["tmp_name"],$target);
	     if($execute){
	      $_SESSION["SuccessMessage"]="Post Updated Successfully";
	      redirect_to("posts.php");
	    }else {
	      $_SESSION["ErrorMessage"]= "Something went wrong. Try Again !";
	      redirect_to("posts.php");
	    }
  }
} //Ending of Submit Button If-Condition
 ?>
<?php require_once("includes/header.php"); ?>
<?php require_once("includes/admin-nav.php"); ?>

<section class="container py-2 mt-4 mb-3">
		<div class="row">
			<div class="offset-lg-1 col-lg-10" style="min-height: 500px;">
				<?php 
					echo ErrorMessage();
					echo SuccessMessage();

					// Fetching Existing content
					global $connectingDB;	
					$sql = "SELECT * FROM posts WHERE id='$serarchQueryPrameter'";
					$stmt = $connectingDB->query($sql);
					while ($dataRows = $stmt->fetch()) {
						$titleToBeUpdated = $dataRows['title'];
						$categoryToBeUpdated = $dataRows['category'];
						$imageToBeUpdated = $dataRows['image'];
						$postToBeUpdated = $dataRows['post'];
					}
				 ?>
				<form action="editPost.php?id=<?php echo $serarchQueryPrameter?>" method="post" class="" enctype="multipart/form-data">
					<div class="card bg-secondary text-light mb-3">
						<div class="card-header">
							<h2 class="card-title mb-1 text-4 text-light">Edit Post</h2>
						</div>
						<div class="card-body bg-dark">
							<div class="form-group">
								<label for="postTitle"><span class="field-info">Post title: </span></label>
								<input type="text" class="form-control" name="PostTitle" id="title" placeholder="Add Post" value="<?php echo $titleToBeUpdated?>">
							</div>
							<div class="form-group">
								<span class="field-info" style="color: #fff;">Existing Category: <strong><?php echo $categoryToBeUpdated; ?></strong></span><br>
								<label for="CategoryTitle"><span class="field-info">Choose Category:</span></label>
								<select class="form-control custom-select" id="CategoryTitle" name="Category">
									<?php 
										global $connectingDB;
										$sql = "SELECT id,title FROM categories";
										$stmt = $connectingDB->query($sql);
										while ($dataRows = $stmt->fetch()) {
											$id = $dataRows['id'];
											$categoryName = $dataRows['title'];
									?>
					<option <?php if($categoryName == $categoryToBeUpdated){echo "selected";}?>>
						<?php echo $categoryName; ?>
					</option>

									<?php } ?>
									
								</select>
							</div>
							<div class="form-group">
								<div class="custom-file">
									<span class="field-info">Existing Image: </span><br>
									 <img  class="my-3" src="uploads/<?php echo $imageToBeUpdated;?>" width="120"; height="100"; >
									<input class="custom-file-input bg-light" type="File" name="Image" id="imageSelect" value="">
									<label for="imageSelect" class="custom-file-label">
										<?php 
											if($imageToBeUpdated){
												echo $imageToBeUpdated;
											} else {
												echo "Image Selected";
											}
										 ?>
									</label>
								</div>
							</div>
							<div class="form-group">
								<label for="Post"><span class="field-info">Post Description: </span></label>
								<textarea class="form-control" id="post" name="PostDescription" rows="8" cols="80">
									<?php echo $postToBeUpdated;?>
								</textarea>
							</div>
							<div class="row py-2">
				                  <div class="col-lg-6">
				                    <a href="dashboard.php" class="cardButton btn-block text-center"><i class="fas fa-arrow-left"></i> Back to Dashbord</a>
				                  </div>
				                  <div class="col-lg-6">
				                    <button type="submit" name="Submit" class="cardSubmit btn-block"><i class="fas fa-check"></i> Update</button>
				                  </div>
				           </div>
						</div>
					</div>
				</form>
				
			</div>
		</div>
	</section>

<?php require_once("includes/footer.php"); ?>