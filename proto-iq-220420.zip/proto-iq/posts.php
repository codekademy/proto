<?php require_once("includes/db.php"); ?>	
<?php require_once("includes/functions.php"); ?>	
<?php require_once("includes/sessions.php"); ?>	

<?php require_once("includes/header.php"); ?>
<?php require_once("includes/admin-nav.php"); ?>

<!-- HEADER -->
    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row py-3">
          <div class="col-md-12 mb-4">
          		<h1 class="text-center"><i class="far fa-heart" style="color: red"></i>Posts Manage</h1>
          </div>
          <div class="col-lg-3 mb-2">

            <a href="add-new-post.php" class="myButton btn-block"><i class="fas fa-edit"></i> Add New Post</a>

          </div>
          <div class="col-lg-3 mb-2">
            <a href="category.php" class="myButton btn-block"><i class="fas fa-folder-plus"></i> Add New Category</a>
          </div>
          <div class="col-lg-3 mb-2">
            <a href="admins.php" class="myButton btn-block"><i class="fas fa-user-plus"></i> Add New Admin</a>
          </div>
          <div class="col-lg-3 mb-2">
            <a href="comments.php" class="myButton btn-block"><i class="fas fa-check"></i> Approve Comments</a>
          </div>
        </div>
      </div>
    </header>
    <!-- HEADER END -->

   <!-- Main Area -->
    <section class="container py-4 mb-4">
      <div class="row">
        <div class="col-lg-12">
          <?php
           echo ErrorMessage();
           echo SuccessMessage();
           ?>
          <table class="table table-striped table-hover">
            <thead class="thead-dark">
            <tr>
              <th>#</th>
              <th>Title</th>
              <th>Category</th>
              <th>Date&Time</th>
              <th>Author</th>
              <th>Banner</th>
              <th>Comments</th>
              <th>Action</th>
              <th>Live Preview</th>
            </tr>
            </thead>

            <?php
                    global $connectingDB;
                    $sql  = "SELECT * FROM posts ORDER BY id desc";
                    $stmt = $connectingDB->query($sql);
                    $sr = 0;
                    while ($dataRows = $stmt->fetch()) {
                      $id        = $dataRows["id"];
                      $dateTime  = $dataRows["datetime"];
                      $postTitle = $dataRows["title"];
                      $category  = $dataRows["category"];
                      $admin     = $dataRows["author"];
                      $image     = $dataRows["image"];
                      $postText  = $dataRows["post"];
                      $sr++;
            ?>
                    
  		<tbody>
        <tr>
          <td>
              <?php echo $sr; ?>
          </td>
          <td>
          	<?php if(strlen($postTitle)>20){$postTitle = substr($postTitle,0,18).'..';}
            	echo $postTitle;
             ?>
           </td>
           <td>
             <?php
              	  if(strlen($category)>8){$category= substr($category,0,8).'..';} 
                  echo $category ;
               ?>
           </td>
           <td>
               <?php
              	  if(strlen($dateTime)>11){$dateTime= substr($dateTime,0,11).'..';}
                  echo $dateTime ;
              ?>
          </td>
          <td>
             <?php
              	  if(strlen($admin)>6){$admin= substr($admin,0,6).'..';}
                  echo $admin ;
               ?>
          </td>
          <td><img src="uploads/<?php echo $image ; ?>" width="170" height="50"</td>
          <td>
               Comments
          </td>
          <td>
           <a href="editPost.php?id=<?php echo $id; ?>" target="_blank"><span class="btn btn-warning">Edit</span></a>
           <a href="deletePost.php?id=<?php echo $id; ?>" target="_blank"><span class="btn btn-danger">Delete</span></a>
          </td>
          <td>
            <a href="#"><span class="btn btn-primary" target="_blank">Live Preview</span></a>
              
          </td>
              
        </tr>
        </tbody>
            <?php } ?>   <!--  Ending of While loop -->
          </table>
        </div>
      </div>
    </section>
    <!-- Main Area End --> 


<?php require_once("includes/footer.php"); ?>