<?php require_once("includes/db.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/sessions.php"); ?>
<?php 
if(isset($_POST["Submit"])){
	$userName = $_POST["Username"];
  	$password = $_POST["Password"];
  	if (empty($userName)||empty($password)) {
    $_SESSION["ErrorMessage"]= "All fields must be filled out";
    redirect_to("login.php");
    }else {
    // code for checking username and password from Database
	    $found_account=Login_Attempt($userName,$password);
	    if ($found_account) {
	      $_SESSION["UserId"]=$found_account["id"];
	      $_SESSION["UserName"]=$found_account["username"];
	      $_SESSION["AdminName"]=$found_account["aname"];
	      $_SESSION["SuccessMessage"]= "Wellcome ".$_SESSION["AdminName"]."!";
	      redirect_to("dashboard.php");
	    }else {
	      $_SESSION["ErrorMessage"]="Incorrect Username/Password";
	      redirect_to("login.php");
	    }
	}
}

 ?>



<?php require_once("includes/header.php"); ?>

  <!-- NAVBAR -->
  
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark top-nav bg-pattren">
      <div class="container">
        <a href="#" class="navbar-brand" style="text-shadow: 4px 4px 3px rgba(0,0,0,0.48); letter-spacing: 1.5px; font-size: 24px;"> Tahir Shafi</a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarcollapseCMS">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarcollapseCMS">
        
        </div>
      </div>
  </nav>
    
  <!-- NAVBAR END -->

  <!-- HEADER -->
    <header class="bg-dark text-white">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          </div>
        </div>
      </div>
    </header>
    <!-- HEADER END -->

	<!-- Main Area Start -->
    <section class="container py-2 mb-4">
      <div class="row">
        <div class="offset-sm-3 col-sm-6" style="min-height:500px;">
          <br><br><br>
          <?php
           echo ErrorMessage();
           echo SuccessMessage();
           ?>
          <div class="card bg-secondary text-light">
            <div class="card-header">
              <h4>Wellcome Back !</h4>
              </div>
              <div class="card-body bg-dark">
              <form class="" action="login.php" method="post">
                <div class="form-group">
                  <label for="username"><span class="field-info">Username:</span></label>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text text-white bg-info"> <i class="fas fa-user"></i> </span>
                    </div>
                    <input type="text" class="form-control" name="Username" id="username" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="password"><span class="field-info">Password:</span></label>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text text-white bg-info"> <i class="fas fa-lock"></i> </span>
                    </div>
                    <input type="password" class="form-control" name="Password" id="password" value="">
                  </div>
                </div>
                <input type="submit" name="Submit" class="btn btn-info btn-block" value="Login">
              </form>

            </div>

          </div>

        </div>

      </div>

    </section>
 <!-- Main Area End -->



<?php require_once("includes/footer.php"); ?>