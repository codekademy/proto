<?php require_once("includes/db.php"); ?>
<?php 
	
	function redirect_to($new_location){
		header("Location:".$new_location);
		exit;
	}

	function CheckUserName($userName){
		global $connectingDB;
		$sql = "SELECT username FROM admins WHERE username=:userName";
		$stmt=$connectingDB->prepare($sql);
		$stmt->bindValue(':userName',$userName);
		$stmt->execute();
		$result=$stmt->rowcount();
		if($result==1){
			return true;
		}else{
			return false;
		}
	}

	function Login_Attempt($userName,$password){
	  global $connectingDB;
	  $sql = "SELECT * FROM admins WHERE username=:userName AND password=:passWord LIMIT 1";
	  $stmt = $connectingDB->prepare($sql);
	  $stmt->bindValue(':userName',$userName);
	  $stmt->bindValue(':passWord',$password);
	  $stmt->execute();
	  $result = $stmt->rowcount();
	  if ($result==1) {
	    return $found_account=$stmt->fetch();
	  }else {
	    return null;
	  }
	}

	function Confirm_Login(){
		if(isset($_SESSION["UserId"])){
			return true;
		}else{
			$_SESSION["ErrorMessage"]="Login Required !";
			redirect_to("login.php");
		}
	}

 ?>