<?php require_once("includes/db.php"); ?>
<?php 
	
	function redirect_to($new_location){
		header("Location:".$new_location);
		exit;
	}

	function CheckUserName($userName){
		global $connectingDB;
		$sql = "SELECT username FROM admins WHERE username=:userName";
		$stmt=$connectingDB->prepare($sql);
		$stmt->bindValue(':userName',$userName);
		$stmt->execute();
		$result=$stmt->rowcount();
		if($result==1){
			return true;
		}else{
			return false;
		}
	}
 ?>