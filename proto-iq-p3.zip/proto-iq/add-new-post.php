<?php require_once("includes/db.php"); ?>	
<?php require_once("includes/functions.php"); ?>	
<?php require_once("includes/sessions.php"); ?>	
<?php 
	if(isset($_POST["Submit"])){
		$postTitle = $_POST["PostTitle"];
		$category  = $_POST["Category"];
		$image	   = $_FILES["Image"]["name"];
		$target    = "uploads/".basename($_FILES["Image"]["name"]);	
		$postDescription = $_POST["PostDescription"];
		$admin = "Tahir";
		date_default_timezone_set("Asia/Karachi");
		$currentTime = time();
		$datetime = strftime("%Y-%m-%d %H:%M:%S", $currentTime);


		if(empty($postTitle)){
			$_SESSION["ErrorMessage"] = "Title cant be empty";
			redirect_to("add-new-post.php");
		} elseif(strlen($postTitle) < 3) {
			$_SESSION["ErrorMessage"] = "Post Title should be greater than 5 characters.";
			redirect_to("add-new-post.php");
		} elseif(strlen($postTitle) > 49) {
				$_SESSION["ErrorMessage"] = "Post Description should be less than than 1000 characters.";
				redirect_to("add-new-post.php");
		} else {
			// Query insert for category 
			global $connectingDB;
			$sql = "INSERT INTO posts(datetime,title,category,author,image,post)";
			$sql .= "VALUES(:dateTime,:postTitle,:categoryName,:adminName,:imageName,:postDescription)";
			$stmt = $connectingDB->prepare($sql);
			$stmt->bindValue(':dateTime', $datetime);
			$stmt->bindValue(':postTitle', $postTitle);
			$stmt->bindValue(':categoryName', $category);
			$stmt->bindValue(':adminName', $admin);
			$stmt->bindValue(':imageName', $image);
			$stmt->bindValue(':postDescription', $postDescription);
			$execute=$stmt->execute();
			move_uploaded_file($_FILES["Image"]["tmp_name"],$target);
			if($execute){
				$_SESSION["SuccessMessage"]="Post with id: " . $connectingDB->lastInsertId() . " added Successfully ";
				redirect_to("add-new-post.php");
			} else {
				$_SESSION["ErrorMessage"]="Request not fullfilled. Try Again!";
				redirect_to("add-new-post.php");
			}

		}

	}

 ?>
<?php require_once("includes/header.php"); ?>
<?php require_once("includes/nav.php"); ?>
<section class="container py-2 mt-4 mb-3">
		<div class="row">
			<div class="offset-lg-1 col-lg-10" style="min-height: 500px;">
				<?php 
					echo ErrorMessage();
					echo SuccessMessage();
				 ?>
				<form action="add-new-post.php" method="post" class="" enctype="multipart/form-data">
					<div class="card bg-secondary text-light mb-3">
						<div class="card-header">
							<h2 class="card-title mb-1 text-4 text-light">Add New Post</h2>
						</div>
						<div class="card-body bg-dark">
							<div class="form-group">
								<label for="postTitle"><span class="field-info">Post title: </span></label>
								<input type="text" class="form-control" name="PostTitle" id="title" placeholder="Add Post">
							</div>
							<div class="form-group">
								<label for="CategoryTitle"><span class="field-info">Choose Category:</span></label>
								<select class="form-control custom-select" id="CategoryTitle" name="Category">
									<?php 
										global $connectingDB;
										$sql = "SELECT id,title FROM categories";
										$stmt = $connectingDB->query($sql);
										while ($dataRows = $stmt->fetch()) {
											$id = $dataRows['id'];
											$categoryTitle = $dataRows['title'];
									?>
										<option><?php echo $categoryTitle; ?></option>

									<?php } ?>
									
								</select>
							</div>
							<div class="form-group">
								<div class="custom-file">
									<input class="custom-file-input bg-light" type="File" name="Image" id="imageSelect" value="">
									<label for="imageSelect" class="custom-file-label">Select Image</label>
								</div>
							</div>
							<div class="form-group">
								<label for="Post"><span class="field-info">Post Description: </span></label>
								<textarea class="form-control" id="post" name="PostDescription" rows="8" cols="80"></textarea>
							</div>
							<div class="row py-2">
				                  <div class="col-lg-6">
				                    <a href="dashboard.php" class="cardButton btn-block text-center"><i class="fas fa-arrow-left"></i> Back to Dashbord</a>
				                  </div>
				                  <div class="col-lg-6">
				                    <button type="submit" name="Submit" class="cardSubmit btn-block"><i class="fas fa-check"></i> Publish</button>
				                  </div>
				           </div>
						</div>
					</div>
				</form>
				
			</div>
		</div>
		<!-- Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem delectus ratione, ipsum facilis accusantium doloribus. Iste doloremque tempore, distinctio quod. -->
	</section>
<?php require_once("includes/footer.php"); ?>