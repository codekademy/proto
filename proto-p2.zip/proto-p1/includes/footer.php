      <!-- FOOTER -->
    <footer class="bg-dark text-white bg-pattren">  
        <div class="container">
          <div class="row">
          <div class="col-md-12">
          <p style="line-height: 100px; margin: 0px; color: #c1c1c1; text-shadow: 4px 4px 3px rgba(0,0,0,0.48); letter-spacing: 1.5px; font-size: 24px; font-weight: 300" class="lead text-center">Created By | Tahir Shafi | <span id="year"></span> &copy; All right Reserved.</p>
          
           </div>
         </div>
        </div>
    </footer>
    
    <!-- FOOTER END-->

	     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
	<script>
	  $('#year').text(new Date().getFullYear());
	</script>
</body>
</html>