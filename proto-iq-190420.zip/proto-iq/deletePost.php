<?php require_once("includes/db.php"); ?>	
<?php require_once("includes/functions.php"); ?>	
<?php require_once("includes/sessions.php"); ?>	
<?php 
	$serarchQueryPrameter = $_GET['id'];
		// Fetching Existing content
		global $connectingDB;	
		$sql = "SELECT * FROM posts WHERE id='$serarchQueryPrameter'";
		$stmt = $connectingDB->query($sql);
		while ($dataRows = $stmt->fetch()) {
			$titleToBeDeleted = $dataRows['title'];
			$categoryToBeDeleted = $dataRows['category'];
			$imageToBeDeleted = $dataRows['image'];
			$postToBeDeleted = $dataRows['post'];
	}
	if(isset($_POST['Submit'])){
		global $connectingDB;
		$sql = "DELETE FROM posts WHERE id='$serarchQueryPrameter'";
		$execute = $connectingDB->query($sql);
		
	     if($execute){
	     	  $target_Path_To_Be_Delete = "uploads/$imageToBeDeleted";
	     	  unlink($target_Path_To_Be_Delete);
		      $_SESSION["SuccessMessage"]="Post DELETE Successfully";
		      redirect_to("posts.php");
	    }else {
	      $_SESSION["ErrorMessage"]= "Something went wrong. Try Again !";
	      redirect_to("posts.php");
	    }
 
} //Ending of Submit Button If-Condition
 ?>
<?php require_once("includes/header.php"); ?>
<?php require_once("includes/admin-nav.php"); ?>

<section class="container py-2 mt-4 mb-3">
		<div class="row">
			<div class="offset-lg-1 col-lg-10" style="min-height: 500px;">
				<?php 
					echo ErrorMessage();
					echo SuccessMessage();
				 ?>
				<form action="deletePost.php?id=<?php echo $serarchQueryPrameter?>" method="post" class="" enctype="multipart/form-data">
					<div class="card bg-secondary text-light mb-3">
						<div class="card-header">
							<h2 class="card-title mb-1 text-4 text-light">Delete Post</h2>
						</div>
						<div class="card-body bg-dark">
							<div class="form-group">
								<label for="postTitle"><span class="field-info">Post title: </span></label>
								<input disabled type="text" class="form-control" name="PostTitle" id="title" placeholder="Add Post" value="<?php echo $titleToBeDeleted?>">
							</div>
							<div class="form-group">
								<span class="field-info" style="color: white">Existing Category: <strong><?php echo $categoryToBeDeleted;?></strong></span>
							</div>
							<div class="form-group">
								<div class="custom-file">
								<span class="field-info">Existing Image: </span><br>
								 <img  class="my-3" src="uploads/<?php echo $imageToBeDeleted;?>" width="120"; height="100"; >
								</div>
							</div>
							<div class="form-group">
								<label for="Post"><span class="field-info">Post Title: </span></label>
								<textarea disabled class="form-control" id="post" name="PostDescription" rows="8" cols="80">
									<?php echo $postToBeDeleted;?>
								</textarea>
							</div>
							<div class="row py-2">
				                  <div class="col-lg-6">
				                    <a href="dashboard.php" class="cardButton btn-block text-center"><i class="fas fa-arrow-left"></i> Back to Dashbord</a>
				                  </div>
				                  <div class="col-lg-6">
				                    <button type="submit" name="Submit" class="cardSubmit btn-block"><i class="fas fa-check"></i> Delete</button>
				                  </div>
				           </div>
						</div>
					</div>
				</form>
				
			</div>
		</div>
	</section>

<?php require_once("includes/footer.php"); ?>