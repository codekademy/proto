<?php require_once("includes/db.php"); ?>	
<?php require_once("includes/functions.php"); ?>	
<?php require_once("includes/sessions.php"); ?>	
<?php 
	if(isset($_POST["Submit"])){
	   $userName        = $_POST["Username"];
	   $name            = $_POST["Name"]; //author name
	   $password        = $_POST["Password"];
	   $confirmPassword = $_POST["ConfirmPassword"];
		$admin = $_SESSION["AdminName"];
		date_default_timezone_set("Asia/Karachi");
		$currentTime = time();
		$dateTime = strftime("%Y-%m-%d %H:%M:%S", $currentTime);

		if(empty($userName)||empty($password)||empty($confirmPassword)){
		    $_SESSION["ErrorMessage"]= "All fields must be filled out";
		    redirect_to("admin.php");
		  }elseif (strlen($password)<4) {
		    $_SESSION["ErrorMessage"]= "Password should be greater than 3 characters";
		    redirect_to("admin.php");
		  }elseif ($password !== $confirmPassword) {
		    $_SESSION["ErrorMessage"]= "Password and Confirm Password should match";
		    redirect_to("admin.php");
		  }elseif(CheckUserName($userName)){
		  	$_SESSION["ErrorMessage"]= "Username Exists. Try Another One! ";
		    redirect_to("admin.php");
		  } else {
			// Query insert for category 
			global $connectingDB;
			$sql = "INSERT INTO admins(datetime,username,password,aname,addedby)";
			$sql .= "VALUES(:dateTime,:userName,:password,:aName,:adminName)";
			$stmt = $connectingDB->prepare($sql);
			$stmt->bindValue(':dateTime',$dateTime);
		    $stmt->bindValue(':userName',$userName);
		    $stmt->bindValue(':password',$password);
		    $stmt->bindValue(':aName',$name);
		    $stmt->bindValue(':adminName',$admin);
			$execute=$stmt->execute();
			// var_dump($execute);
			// exit;

		if($execute){
			$_SESSION["SuccessMessage"]="New Admin with the name of ".$name." added Successfully";
			redirect_to("admin.php");
		} else {
			$_SESSION["ErrorMessage"]="Request not fullfilled. Try Again!";
			redirect_to("admin.php");
		}

		}

	}

 ?>
<?php require_once("includes/header.php"); ?>
<?php require_once("includes/admin-nav.php"); ?>
<!-- HEADER -->
    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <h1><i class="far fa-heart" style="color: red"></i> Manage Admin</h1>
          </div>
        </div>
      </div>
    </header>
<!-- HEADER END -->

<section class="container py-2 mt-4 mb-3">
		<div class="row">
			<div class="offset-lg-1 col-lg-10" style="min-height: 500px;">
				<?php 
					echo ErrorMessage();
					echo SuccessMessage();
				 ?>
				<form action="admin.php" method="post" class="">
					<div class="card bg-secondary text-light mb-3">
						<div class="card-header">
							<h2 class="card-title mb-1 text-4 text-light">Add New Admin</h2>
						</div>
						<div class="card-body bg-dark">
							<div class="form-group">
				              <label for="username"> <span class="field-info"> Username: </span></label>
				               <input class="form-control" type="text" name="Username" id="username"  value="">
				            </div>
				            <div class="form-group">
				              <label for="Name"> <span class="field-info"> Name: </span></label>
				               <input class="form-control" type="text" name="Name" id="Name" value="">
				               <small class="text-muted">*Optional</small>
				            </div>
				            <div class="form-group">
				              <label for="Password"> <span class="field-info"> Password: </span></label>
				               <input class="form-control" type="password" name="Password" id="Password" value="">
				            </div>
				            <div class="form-group">
				              <label for="ConfirmPassword"> <span class="field-info"> Confirm Password:</span></label>
				               <input class="form-control" type="password" name="ConfirmPassword" id="ConfirmPassword"  value="">
				            </div>
								<div class="row py-2">
				                  <div class="col-lg-6">
				                    <a href="dashboard.php" class="cardButton btn-block text-center"><i class="fas fa-arrow-left"></i> Back to Dashbord</a>
				                  </div>
				                  <div class="col-lg-6">
				                    <button type="submit" name="Submit" class="cardSubmit btn-block"><i class="fas fa-check"></i> Submit</button>
				                </div>
				           </div>
						</div>
					</div>
				</form>
				
			</div>
		</div>
		
	</section>
<?php require_once("includes/footer.php"); ?>