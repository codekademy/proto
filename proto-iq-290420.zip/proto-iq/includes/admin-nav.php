

<!-- NAVBAR -->
  
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark top-nav bg-pattren">
    <div class="container">
      <a href="#" class="navbar-brand" style="text-shadow: 4px 4px 3px rgba(0,0,0,0.48); letter-spacing: 1.5px; font-size: 24px;"> Tahir Shafi</a>
      <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarcollapseCMS">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarcollapseCMS">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a href="myProfile.php" class="nav-link"> <i class="fas fa-user text-success"></i> My Profile</a>
        </li>
        <li class="nav-item">
          <a href="dashboard.php" class="nav-link">Dashboard</a>
        </li>
        <li class="nav-item">
          <a href="posts.php" class="nav-link">Posts</a>
        </li>
        <li class="nav-item">
          <a href="categories.php" class="nav-link">Categories</a>
        </li>
        <li class="nav-item">
          <a href="admins.php" class="nav-link">Manage Admins</a>
        </li>
        <li class="nav-item">
          <a href="comments.php" class="nav-link">Comments</a>
        </li>
        <li class="nav-item">
          <a href="blog.php?page=1" class="nav-link" target="_blank">Live Blog</a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a href="logout.php" class="nav-link text-danger">
          <i class="fas fa-user-times"></i> Logout</a></li>
      </ul>
      </div>
    </div>
  </nav>
    
    <!-- NAVBAR END -->


