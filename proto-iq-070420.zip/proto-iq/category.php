<?php require_once("includes/db.php"); ?>	
<?php require_once("includes/functions.php"); ?>	
<?php require_once("includes/sessions.php"); ?>	
<?php 
	if(isset($_POST["Submit"])){
		$category = $_POST["CategoryTitle"];
		$admin = "Tahir";
		date_default_timezone_set("Asia/Karachi");
		$currentTime = time();
		$datetime = strftime("%Y-%m-%d %H:%M:%S", $currentTime);

		if(empty($category)){
			$_SESSION["ErrorMessage"] = "All fields must be filled out.";
			redirect_to("category.php");
		} elseif(strlen($category) < 3) {
			$_SESSION["ErrorMessage"] = "Category title should be greater than 2 characters.";
			redirect_to("category.php");
		} elseif(strlen($category) > 49) {
				$_SESSION["ErrorMessage"] = "Category title should be less than than 50 characters.";
				redirect_to("category.php");
		} else {
			// Query insert for category 
			global $connectingDB;
			$sql = "INSERT INTO categories(title, author, datetime)";
			$sql .= "VALUES(:categoryName, :adminName, :dateTime)";
			$stmt = $connectingDB->prepare($sql);
			$stmt->bindValue(':categoryName', $category);
			$stmt->bindValue(':adminName', $admin);
			$stmt->bindValue(':dateTime', $datetime);
			$execute=$stmt->execute();

		if($execute){
			$_SESSION["SuccessMessage"]="Category with id: " . $connectingDB->lastInsertId() . " added Successfully ";
			redirect_to("category.php");
		} else {
			$_SESSION["ErrorMessage"]="Request not fullfilled. Try Again!";
			redirect_to("category.php");
		}

		}

	}

 ?>
<?php require_once("includes/header.php"); ?>
<?php require_once("includes/nav.php"); ?>
<section class="container py-2 mt-4 mb-3">
		<div class="row">
			<div class="offset-lg-1 col-lg-10" style="min-height: 500px;">
				<?php 
					echo ErrorMessage();
					echo SuccessMessage();
				 ?>
				<form action="category.php" method="post" class="">
					<div class="card bg-secondary text-light mb-3">
						<div class="card-header">
							<h2 class="card-title mb-1 text-4 text-light">Add New Category</h2>
						</div>
						<div class="card-body bg-dark">
							<div class="form-group">
								<label for="CategoryTitle"><span class="field-info">Category title: </span></label>
								<input type="text" class="form-control" name="CategoryTitle" id="title" placeholder="Add Category">
							</div>
							<div class="row py-2">
				                  <div class="col-lg-6">
				                    <a href="dashboard.php" class="cardButton btn-block text-center"><i class="fas fa-arrow-left"></i> Back to Dashbord</a>
				                  </div>
				                  <div class="col-lg-6">
				                    <button type="submit" name="Submit" class="cardSubmit btn-block"><i class="fas fa-check"></i> Publish</button>
				                  </div>
				           </div>
						</div>
					</div>
				</form>
				
			</div>
		</div>
		
	</section>
<?php require_once("includes/footer.php"); ?>