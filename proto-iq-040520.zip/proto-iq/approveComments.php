<?php require_once("includes/db.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/sessions.php"); ?>
<?php
if(isset($_GET["id"])){
  $searchQueryParameter = $_GET["id"];
  global $connectingDB;
  $admin = $_SESSION["AdminName"];
  $sql = "UPDATE comments SET status='ON', approvedby='$admin' WHERE id='$searchQueryParameter'";
  $execute = $connectingDB->query($sql);
  if ($execute) {
    $_SESSION["SuccessMessage"]="Comment Approved Successfully ! ";
    redirect_to("comment.php");
    // code...
  }else {
    $_SESSION["ErrorMessage"]="Something Went Wrong. Try Again !";
    redirect_to("comment.php");
  }
}
?>