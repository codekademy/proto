<?php require_once("includes/db.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php require_once("includes/sessions.php"); ?>
<?php
if(isset($_GET["id"])){
  $searchQueryParameter = $_GET["id"];
  global $connectingDB;
  $sql = "DELETE FROM comments WHERE id='$searchQueryParameter'";
  $execute = $connectingDB->query($sql);
  if ($execute) {
    $_SESSION["SuccessMessage"]="Comment Deleted Successfully ! ";
    redirect_to("comment.php");
    // code...
  }else {
    $_SESSION["ErrorMessage"]="Something Went Wrong. Try Again !";
    redirect_to("comment.php");
  }
}
?>