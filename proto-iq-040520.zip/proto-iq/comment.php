<?php require_once("includes/db.php"); ?>	
<?php require_once("includes/functions.php"); ?>	
<?php require_once("includes/sessions.php"); ?>	
<?php
$_SESSION["TrackingURL"]=$_SERVER["PHP_SELF"];
Confirm_Login(); ?>

<?php require_once("includes/header.php"); ?>
<?php require_once("includes/admin-nav.php"); ?>

	<!-- HEADER -->
    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <h1><i class="fas fa-comments" style="color:#27aae1;"></i> Manage Comments</h1>
          </div>
        </div>
      </div>
    </header>
    <!-- HEADER END -->

    <!-- Main Area Start -->
    <section class="container py-2 mb-4">
      <div class="row" style="min-height:30px;">
        <div class="col-lg-12" style="min-height:400px;">
          <?php
           echo ErrorMessage();
           echo SuccessMessage();
           ?>
          <h2>Un-Approved Comments</h2>
          <table class="table table-striped table-hover">
            <thead class="thead-dark">
              <tr>
                <th>No. </th>
                <th>Date&Time</th>
                <th>Name</th>
                <th>Comment</th>
                <th>Aprove</th>
                <th>Action</th>
                <th>Details</th>
              </tr>
            </thead>
          <?php
          global $connectingDB;
          $sql = "SELECT * FROM comments WHERE status='OFF' ORDER BY id desc";
          $execute =$connectingDB->query($sql);
          $srNo = 0;
          while ($dataRows=$execute->fetch()) {
            $commentId = $dataRows["id"];
            $dateTimeOfComment = $dataRows["datetime"];
            $commenterName = $dataRows["name"];
            $commentContent= $dataRows["comment"];
            $commentPostId = $dataRows["post_id"];
            $srNo++;
            //if(strlen($commenterName)>10){$commenterName = substr($commenterName,0,10).'..';}
          ?>
          <tbody>
            <tr>
              <td><?php echo htmlentities($srNo); ?></td>
              <td><?php echo htmlentities($dateTimeOfComment); ?></td>
              <td><?php echo htmlentities($commenterName); ?></td>
              <td><?php echo htmlentities($commentContent); ?></td>
              <td> <a href="approveComments.php?id=<?php echo $commentId;?>" class="btn btn-success">Approve</a>  </td>
              <td> <a href="deleteComments.php?id=<?php echo $commentId;?>" class="btn btn-danger">Delete</a>  </td>
              <td style="min-width:140px;"> <a class="btn btn-primary"href="fullPost.php?id=<?php echo $commentPostId; ?>" target="_blank">Live Preview</a> </td>
            </tr>
          </tbody>
          <?php } ?>
          </table>
		
		<h2>Approved Comments</h2>
          <table class="table table-striped table-hover">
            <thead class="thead-dark">
              <tr>
                <th>No. </th>
                <th>Date&Time</th>
                <th>Name</th>
                <th>Comment</th>
                <th>Revert</th>
                <th>Action</th>
                <th>Details</th>
              </tr>
            </thead>
          <?php
          global $connectingDB;
          $sql = "SELECT * FROM comments WHERE status='ON' ORDER BY id desc";
          $execute =$connectingDB->query($sql);
          $srNo = 0;
          while ($dataRows=$execute->fetch()) {
            $commentId = $dataRows["id"];
            $dateTimeOfComment = $dataRows["datetime"];
            $commenterName = $dataRows["name"];
            $commentContent= $dataRows["comment"];
            $commentPostId = $dataRows["post_id"];
            $srNo++;
          ?>
          <tbody>
            <tr>
              <td><?php echo htmlentities($srNo); ?></td>
              <td><?php echo htmlentities($dateTimeOfComment); ?></td>
              <td><?php echo htmlentities($commenterName); ?></td>
              <td><?php echo htmlentities($commentContent); ?></td>
              <td style="min-width: 140px;"> <a href="disapparovedComment.php?id=<?php echo $commentId;?>" class="btn btn-warning">Dis-Approve</a>  </td>
              <td> <a href="deleteComment.php?id=<?php echo $commentId;?>" class="btn btn-danger">Delete</a>  </td>
              <td style="min-width:140px;"> <a class="btn btn-primary"href="fullPost.php?id=<?php echo $commentPostId; ?>" target="_blank">Live Preview</a> </td>
            </tr>
          </tbody>
          <?php } ?>
          </table>



      	</div>
  		</div>
	</section>

<?php require_once("includes/footer.php"); ?>