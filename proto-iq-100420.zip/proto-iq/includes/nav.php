 <!-- NAVBAR -->
  
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark top-nav bg-pattren">
      <div class="container">
        <a href="#" class="navbar-brand" style="text-shadow: 4px 4px 3px rgba(0,0,0,0.48); letter-spacing: 1.5px; font-size: 24px;"> Tahir Shafi</a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarcollapseCMS">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarcollapseCMS">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a href="#" class="nav-link"> <i class="fas fa-user text-success"></i> Home</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">About Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Contact Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Features</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
             <form class="form-inline d-none d-sm-block" action="blog.php">
                <div class="form-group">
                <input class="form-control mr-2" type="text" name="Search" placeholder="Search here"value="">
                <button  class="btn btn-primary" name="SearchButton">Go</button>
                </div>
            </form>
        </ul>
        </div>
      </div>
  </nav>
    
    <!-- NAVBAR END -->