<?php 

	$DSN = 'mysql:host = localhost; dbname=proto';
	$connectingDB = new PDO($DSN,'root','');

 ?>